package net.sf.JRecord.cgen.def;

public interface IIndex {
	public int getIndex(int indexNumber);
}
